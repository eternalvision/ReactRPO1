import * as actions from "../redux/actions";
import {
    FETCH_PHOTO_START,
    FETCH_PHOTO_SUCCESS,
    FETCH_PHOTO_FAILURE,
} from "../redux/actions";

describe("nasa actions", () => {
    it("should create an action to start fetching photo", () => {
        const expectedAction = {
            type: FETCH_PHOTO_START,
        };
        expect(actions.fetchPhotoStart()).toEqual(expectedAction);
    });
});
