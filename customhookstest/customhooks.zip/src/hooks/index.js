import { useCounter } from "./useCounter";
import { useMousePosition } from "./useMousePosition";

export const Hooks = { useCounter, useMousePosition };
